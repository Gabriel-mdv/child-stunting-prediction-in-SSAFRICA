"""
STEP 3 — FastAPI Backend
=========================
Loads the trained XGBoost model and serves predictions
via a REST API.

HOW TO RUN:
    pip install fastapi uvicorn
    python 3_api.py

API ENDPOINTS:
    POST /predict   — returns risk level, probability, factors, recommendation
    GET  /health    — health check
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
import pickle
import os
import numpy as np
import pandas as pd
import shap
import uvicorn
import warnings
warnings.filterwarnings('ignore')

# ── LOAD MODEL ARTIFACTS ─────────────────────────────────────────────────────
MODELS_DIR = 'models'

def load_artifacts():
    artifacts = {}
    try:
        with open(os.path.join(MODELS_DIR, 'xgboost_model.pkl'), 'rb') as f:
            artifacts['model'] = pickle.load(f)
        with open(os.path.join(MODELS_DIR, 'shap_explainer.pkl'), 'rb') as f:
            artifacts['explainer'] = pickle.load(f)
        with open(os.path.join(MODELS_DIR, 'feature_names.pkl'), 'rb') as f:
            artifacts['features'] = pickle.load(f)
        print("✓ Model artifacts loaded successfully")
    except FileNotFoundError as e:
        print(f"WARNING: {e}")
        print("Run 2_model_training.py first to generate model files.")
        artifacts['model'] = None
    return artifacts

artifacts = load_artifacts()

# ── FASTAPI APP ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="CHW Stunting Prediction API",
    description="Predicts child stunting risk for community health workers",
    version="1.0.0"
)

# Allow frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── INPUT SCHEMA ──────────────────────────────────────────────────────────────
class ChildInput(BaseModel):
    # Country
    country: int = Field(..., description="1=Nigeria, 2=Rwanda, 3=Ethiopia")

    # Child
    child_age_months:   float = Field(..., ge=0,  le=59,  description="Age in months")
    child_sex:          int   = Field(..., ge=1,  le=2,   description="1=Male, 2=Female")
    birth_weight_grams: float = Field(..., ge=500, le=6000, description="Birth weight in grams")

    # Maternal
    mother_age:       float = Field(..., ge=15, le=49, description="Mother's age in years")
    mother_education: int   = Field(..., ge=0,  le=3,  description="0=None,1=Primary,2=Secondary,3=Higher")
    mother_bmi:       float = Field(..., ge=10, le=60, description="Mother's BMI")

    # Household
    wealth_index:    int   = Field(..., ge=1, le=5, description="1=Poorest to 5=Richest")
    water_source:    int   = Field(..., ge=0, le=2, description="0=Piped,1=Well,2=Surface")
    sanitation_type: int   = Field(..., ge=0, le=2, description="0=Flush,1=Pit latrine,2=None")
    household_size:  float = Field(..., ge=1, le=30, description="Number of people in household")

    # Geographic
    urban_rural: int = Field(..., ge=1, le=2, description="1=Urban, 2=Rural")
    region:      int = Field(..., ge=1,       description="Region code within country")


# ── HELPER: GET RISK FACTORS FROM SHAP ───────────────────────────────────────
FEATURE_LABELS = {
    'child_age_months':   'Child age',
    'child_sex':          'Child sex',
    'birth_weight_grams': 'Birth weight',
    'mother_age':         'Mother age',
    'mother_education':   'Mother education',
    'mother_bmi':         'Mother BMI',
    'wealth_index':       'Household wealth',
    'water_source':       'Water source',
    'sanitation_type':    'Sanitation access',
    'household_size':     'Household size',
    'urban_rural':        'Location (urban/rural)',
    'region':             'Geographic region',
    'country':            'Country context',
}

RISK_MESSAGES = {
    'birth_weight_grams': {
        'high': 'Low birth weight is significantly increasing risk',
        'low':  'Normal birth weight is reducing risk',
    },
    'mother_education': {
        'high': 'Low maternal education is increasing risk',
        'low':  'Higher maternal education is reducing risk',
    },
    'wealth_index': {
        'high': 'Low household wealth is increasing risk',
        'low':  'Higher household wealth is reducing risk',
    },
    'water_source': {
        'high': 'Unsafe water source is increasing risk',
        'low':  'Safe water source is reducing risk',
    },
    'sanitation_type': {
        'high': 'Poor sanitation is increasing risk',
        'low':  'Good sanitation is reducing risk',
    },
    'urban_rural': {
        'high': 'Rural location is increasing risk',
        'low':  'Urban location is reducing risk',
    },
    'country': {
        'high': 'Country-level health context is increasing risk',
        'low':  'Country-level health context is reducing risk',
    },
    'child_age_months': {
        'high': 'Child age is a risk factor at this stage',
        'low':  'Child age is not a concern at this stage',
    },
    'mother_bmi': {
        'high': 'Low maternal BMI is increasing risk',
        'low':  'Maternal BMI is not a concern',
    },
    'household_size': {
        'high': 'Large household size is increasing risk',
        'low':  'Household size is not a concern',
    },
}

def get_risk_factors(input_df, explainer, feature_names):
    """Get top 3 risk factors using SHAP values."""
    try:
        shap_values = explainer.shap_values(input_df)
        if isinstance(shap_values, list):
            shap_vals = shap_values[1][0]
        else:
            shap_vals = shap_values[0]

        # Pair feature names with SHAP values
        factors = []
        for i, (feat, val) in enumerate(zip(feature_names, shap_vals)):
            direction = 'high' if val > 0 else 'low'
            label = FEATURE_LABELS.get(feat, feat)
            message = RISK_MESSAGES.get(feat, {}).get(
                direction, f"{label} is {'increasing' if val > 0 else 'reducing'} risk"
            )
            factors.append({
                'feature':   feat,
                'label':     label,
                'shap_value': float(val),
                'direction': direction,
                'message':   message,
            })

        # Sort by absolute SHAP value, take top 3 that INCREASE risk
        increasing = [f for f in factors if f['direction'] == 'high']
        increasing.sort(key=lambda x: abs(x['shap_value']), reverse=True)

        return increasing[:3] if increasing else factors[:3]

    except Exception as e:
        print(f"SHAP error: {e}")
        return []


# ── PREDICT ENDPOINT ──────────────────────────────────────────────────────────
@app.post("/predict")
def predict(child: ChildInput):
    if artifacts.get('model') is None:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Run 2_model_training.py first."
        )

    model    = artifacts['model']
    explainer = artifacts['explainer']
    features  = artifacts['features']

    # Build input dataframe in correct column order
    input_dict = {
        'child_age_months':   child.child_age_months,
        'child_sex':          child.child_sex,
        'birth_weight_grams': child.birth_weight_grams,
        'mother_age':         child.mother_age,
        'mother_education':   child.mother_education,
        'mother_bmi':         child.mother_bmi,
        'wealth_index':       child.wealth_index,
        'water_source':       child.water_source,
        'sanitation_type':    child.sanitation_type,
        'household_size':     child.household_size,
        'urban_rural':        child.urban_rural,
        'region':             child.region,
        'country':            child.country,
    }

    # Keep only features the model was trained on, in correct order
    input_df = pd.DataFrame([input_dict])[features]

    # ── PREDICTION ──────────────────────────────────────────────────────────
    probability = float(model.predict_proba(input_df)[0][1])
    prediction  = int(model.predict(input_df)[0])

    # ── RISK LEVEL ───────────────────────────────────────────────────────────
    if probability >= 0.60:
        risk_level = "HIGH"
        risk_color = "red"
    elif probability >= 0.40:
        risk_level = "MODERATE"
        risk_color = "orange"
    else:
        risk_level = "LOW"
        risk_color = "green"

    # ── RECOMMENDATION ───────────────────────────────────────────────────────
    recommendations = {
        "HIGH": {
            "action":  "Refer immediately",
            "detail":  "This child has a high probability of stunting. Refer to the nearest nutrition clinic or health facility within 7 days. Initiate supplementary feeding if available.",
            "followup": "Follow up within 1 week to confirm referral was completed."
        },
        "MODERATE": {
            "action":  "Monitor closely",
            "detail":  "This child is at moderate risk. Schedule a follow-up home visit within 2 weeks. Provide caregiver counselling on nutrition and hygiene.",
            "followup": "Reassess in 4 weeks. Refer if condition worsens."
        },
        "LOW": {
            "action":  "Continue standard care",
            "detail":  "This child currently shows low risk of stunting. Continue routine growth monitoring and standard preventive care.",
            "followup": "Next scheduled visit as per standard protocol."
        }
    }

    # ── SHAP RISK FACTORS ────────────────────────────────────────────────────
    risk_factors = get_risk_factors(input_df, explainer, features)

    # ── COUNTRY NAME ─────────────────────────────────────────────────────────
    country_names = {1: "Nigeria", 2: "Rwanda", 3: "Ethiopia"}

    return {
        "prediction": {
            "stunted":     prediction,
            "probability": round(probability * 100, 1),
            "risk_level":  risk_level,
            "risk_color":  risk_color,
        },
        "recommendation": recommendations[risk_level],
        "risk_factors":   risk_factors,
        "country":        country_names.get(child.country, "Unknown"),
    }


# ── HEALTH CHECK ──────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    model_loaded = artifacts.get('model') is not None
    return {
        "status":       "ok" if model_loaded else "model_not_loaded",
        "model_loaded": model_loaded,
        "version":      "1.0.0"
    }


# ── SERVE FRONTEND ────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def root():
    html_path = os.path.join('frontend', 'templates', 'index.html')
    if os.path.exists(html_path):
        with open(html_path, 'r') as f:
            return f.read()
    return "<h1>CHW Stunting Prediction API</h1><p>Frontend not found. See /docs for API.</p>"


# ── RUN ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    uvicorn.run(
        "3_api:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
