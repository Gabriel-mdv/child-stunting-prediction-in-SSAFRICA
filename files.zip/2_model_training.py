"""
STEP 2 — Model Training
========================
Loads combined_data.csv, trains 3 models, evaluates them,
saves the best model (XGBoost) + SHAP explainer.

HOW TO RUN:
    python 2_model_training.py

OUTPUT:
    models/xgboost_model.pkl
    models/shap_explainer.pkl
    models/feature_names.pkl
    models/model_report.txt
"""

import pandas as pd
import numpy as np
import pickle
import os
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    recall_score, precision_score, f1_score,
    roc_auc_score, classification_report, confusion_matrix
)
from sklearn.pipeline import Pipeline

import xgboost as xgb
import shap

# ── CONFIGURATION ───────────────────────────────────────────────────────────
DATA_PATH   = os.path.join('data', 'combined_data.csv')
MODELS_DIR  = 'models'
RANDOM_SEED = 42

# Features used for training (excludes country_name, stunted)
FEATURE_COLS = [
    'child_age_months',
    'child_sex',
    'birth_weight_grams',
    'mother_age',
    'mother_education',
    'mother_bmi',
    'wealth_index',
    'water_source',
    'sanitation_type',
    'household_size',
    'urban_rural',
    'region',
    'country',          # Country as a feature
]

TARGET_COL = 'stunted'


# ── LOAD DATA ────────────────────────────────────────────────────────────────
def load_data():
    print(f"\n{'='*50}")
    print("  CHW STUNTING PREDICTION — MODEL TRAINING")
    print(f"{'='*50}")

    if not os.path.exists(DATA_PATH):
        print(f"ERROR: {DATA_PATH} not found. Run 1_data_pipeline.py first.")
        return None, None

    df = pd.read_csv(DATA_PATH)
    print(f"\nLoaded: {len(df):,} rows")
    print(f"Stunting prevalence: {df[TARGET_COL].mean()*100:.1f}%")

    # Check all feature columns exist
    missing = [col for col in FEATURE_COLS if col not in df.columns]
    if missing:
        print(f"WARNING: Missing feature columns: {missing}")
        FEATURE_COLS_USE = [c for c in FEATURE_COLS if c in df.columns]
    else:
        FEATURE_COLS_USE = FEATURE_COLS

    X = df[FEATURE_COLS_USE].copy()
    y = df[TARGET_COL].copy()

    print(f"Features used: {len(FEATURE_COLS_USE)}")
    print(f"  {FEATURE_COLS_USE}")

    return X, y


# ── EVALUATE MODEL ───────────────────────────────────────────────────────────
def evaluate(name, model, X_test, y_test):
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    recall    = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    f1        = f1_score(y_test, y_pred)
    roc_auc   = roc_auc_score(y_test, y_proba)

    print(f"\n  {name}")
    print(f"    Recall:    {recall:.3f}  (target > 0.75)")
    print(f"    Precision: {precision:.3f}  (target > 0.70)")
    print(f"    F1 Score:  {f1:.3f}  (target > 0.72)")
    print(f"    ROC-AUC:   {roc_auc:.3f}  (target > 0.75)")

    return {
        'name':      name,
        'model':     model,
        'recall':    recall,
        'precision': precision,
        'f1':        f1,
        'roc_auc':   roc_auc,
        'y_pred':    y_pred,
        'y_proba':   y_proba,
    }


# ── MAIN TRAINING ────────────────────────────────────────────────────────────
def train():
    os.makedirs(MODELS_DIR, exist_ok=True)

    # Load data
    X, y = load_data()
    if X is None:
        return

    # ── TRAIN/TEST SPLIT ─────────────────────────────────────────────────────
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.2,
        random_state=RANDOM_SEED,
        stratify=y  # Keep same stunting ratio in both splits
    )
    print(f"\nTrain: {len(X_train):,} rows | Test: {len(X_test):,} rows")

    # ── CLASS IMBALANCE CHECK ─────────────────────────────────────────────────
    # Stunting ~35-46%: mild imbalance, use scale_pos_weight for XGBoost
    neg = (y_train == 0).sum()
    pos = (y_train == 1).sum()
    scale_pos_weight = neg / pos
    print(f"Class ratio (neg/pos): {scale_pos_weight:.2f}")

    # ── DEFINE 3 MODELS ──────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("Training models...")
    print(f"{'='*50}")

    models_to_train = {

        # 1. Logistic Regression (baseline)
        'Logistic Regression': Pipeline([
            ('scaler', StandardScaler()),
            ('clf', LogisticRegression(
                max_iter=1000,
                random_state=RANDOM_SEED,
                class_weight='balanced'
            ))
        ]),

        # 2. Random Forest
        'Random Forest': RandomForestClassifier(
            n_estimators=200,
            max_depth=10,
            min_samples_leaf=10,
            class_weight='balanced',
            random_state=RANDOM_SEED,
            n_jobs=-1
        ),

        # 3. XGBoost (primary model)
        'XGBoost': xgb.XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            scale_pos_weight=scale_pos_weight,  # Handle class imbalance
            use_label_encoder=False,
            eval_metric='logloss',
            random_state=RANDOM_SEED,
            n_jobs=-1,
            verbosity=0,
        ),
    }

    # ── TRAIN + EVALUATE ─────────────────────────────────────────────────────
    results = []
    for name, model in models_to_train.items():
        print(f"\nTraining {name}...")
        model.fit(X_train, y_train)

        # 5-fold cross validation on training set
        cv_scores = cross_val_score(
            model, X_train, y_train,
            cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED),
            scoring='roc_auc',
            n_jobs=-1
        )
        print(f"  CV ROC-AUC: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")

        result = evaluate(name, model, X_test, y_test)
        results.append(result)

    # ── COMPARE RESULTS ──────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("MODEL COMPARISON SUMMARY")
    print(f"{'='*50}")
    print(f"{'Model':<25} {'Recall':>8} {'F1':>8} {'ROC-AUC':>10}")
    print("-" * 55)
    for r in results:
        print(f"{r['name']:<25} {r['recall']:>8.3f} {r['f1']:>8.3f} {r['roc_auc']:>10.3f}")

    # Pick best model by ROC-AUC
    best = max(results, key=lambda x: x['roc_auc'])
    print(f"\nBest model: {best['name']} (ROC-AUC: {best['roc_auc']:.3f})")

    # ── DETAILED REPORT FOR BEST MODEL ───────────────────────────────────────
    print(f"\nDetailed report for {best['name']}:")
    print(classification_report(y_test, best['y_pred'],
                                 target_names=['Not Stunted', 'Stunted']))

    # Confusion matrix
    cm = confusion_matrix(y_test, best['y_pred'])
    print(f"Confusion Matrix:")
    print(f"  True Negative  (correct 'not stunted'): {cm[0,0]:,}")
    print(f"  False Positive (wrongly flagged):        {cm[0,1]:,}")
    print(f"  False Negative (missed stunted child):   {cm[1,0]:,}")
    print(f"  True Positive  (correctly caught):       {cm[1,1]:,}")

    # ── SHAP EXPLANATION ─────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("Computing SHAP values...")

    # For XGBoost we use TreeExplainer (fast)
    # For others, we use a sample-based explainer
    best_model = best['model']

    if 'XGBoost' in best['name']:
        explainer = shap.TreeExplainer(best_model)
    elif 'Random Forest' in best['name']:
        explainer = shap.TreeExplainer(best_model)
    else:
        # Logistic Regression: use LinearExplainer on a sample
        explainer = shap.LinearExplainer(
            best_model.named_steps['clf'],
            shap.sample(X_train, 100)
        )

    # Compute SHAP on test set sample (500 rows for speed)
    X_sample = X_test.sample(min(500, len(X_test)), random_state=RANDOM_SEED)
    shap_values = explainer.shap_values(X_sample)

    # For binary classification, take the positive class values
    if isinstance(shap_values, list):
        shap_vals = shap_values[1]
    else:
        shap_vals = shap_values

    # Feature importance from SHAP
    feature_importance = pd.DataFrame({
        'feature': X.columns.tolist(),
        'importance': np.abs(shap_vals).mean(axis=0)
    }).sort_values('importance', ascending=False)

    print("\nTop 12 features by SHAP importance:")
    for _, row in feature_importance.iterrows():
        bar = '█' * int(row['importance'] * 50)
        print(f"  {row['feature']:<25} {row['importance']:.4f}  {bar}")

    # ── SAVE EVERYTHING ───────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("Saving model and artifacts...")

    # Save best model
    model_path = os.path.join(MODELS_DIR, 'xgboost_model.pkl')
    with open(model_path, 'wb') as f:
        pickle.dump(best_model, f)
    print(f"  Model saved:    {model_path}")

    # Save SHAP explainer
    explainer_path = os.path.join(MODELS_DIR, 'shap_explainer.pkl')
    with open(explainer_path, 'wb') as f:
        pickle.dump(explainer, f)
    print(f"  Explainer saved: {explainer_path}")

    # Save feature names
    feature_path = os.path.join(MODELS_DIR, 'feature_names.pkl')
    with open(feature_path, 'wb') as f:
        pickle.dump(X.columns.tolist(), f)
    print(f"  Features saved: {feature_path}")

    # Save feature importance
    fi_path = os.path.join(MODELS_DIR, 'feature_importance.csv')
    feature_importance.to_csv(fi_path, index=False)
    print(f"  Importance saved: {fi_path}")

    # Save full model report
    report_path = os.path.join(MODELS_DIR, 'model_report.txt')
    with open(report_path, 'w') as f:
        f.write("CHW Stunting Prediction — Model Report\n")
        f.write("="*50 + "\n\n")
        f.write(f"Best model: {best['name']}\n\n")
        f.write("Performance:\n")
        f.write(f"  Recall:    {best['recall']:.3f}\n")
        f.write(f"  Precision: {best['precision']:.3f}\n")
        f.write(f"  F1 Score:  {best['f1']:.3f}\n")
        f.write(f"  ROC-AUC:   {best['roc_auc']:.3f}\n\n")
        f.write("Top Features (SHAP):\n")
        for _, row in feature_importance.iterrows():
            f.write(f"  {row['feature']}: {row['importance']:.4f}\n")
    print(f"  Report saved: {report_path}")

    print(f"\n✓ Training complete! Run 3_api.py next.\n")

    return best_model, explainer, X.columns.tolist()


if __name__ == '__main__':
    train()
