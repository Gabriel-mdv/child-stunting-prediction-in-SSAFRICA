"""
STEP 1 — Data Pipeline
=======================
Loads DHS Children's Recode files for Nigeria, Rwanda, Ethiopia.
Extracts the 12 variables we need, creates the stunting label,
merges into one combined CSV ready for model training.

HOW TO RUN:
    python 1_data_pipeline.py

OUTPUT:
    data/combined_data.csv
    data/pipeline_report.txt
"""

import pandas as pd
import numpy as np
import os
import warnings
warnings.filterwarnings('ignore')

# ── FILE PATHS ──────────────────────────────────────────────────────────────
# Assumes this script is in the same root folder as your dataset/ folder
DATA_PATHS = {
    'Nigeria':  os.path.join('dataset', 'NGKR7BDT', 'NGKR7BFL.DTA'),
    'Rwanda':   os.path.join('dataset', 'RWKR81DT', 'RWKR81FL.DTA'),
    'Ethiopia': os.path.join('dataset', 'ETKR71DT', 'ETKR71FL.DTA'),
}

# ── VARIABLES WE NEED ───────────────────────────────────────────────────────
TARGET      = 'hw70'       # Height-for-age Z-score (x100). <-200 = stunted

FEATURES = {
    'hw1':  'child_age_months',     # Child age in months
    'b4':   'child_sex',            # 1=Male, 2=Female
    'm19':  'birth_weight_grams',   # Birth weight in grams
    'v012': 'mother_age',           # Mother's current age
    'v106': 'mother_education',     # 0=None,1=Primary,2=Secondary,3=Higher
    'v445': 'mother_bmi',           # BMI x100 (e.g. 2250 = 22.5)
    'v190': 'wealth_index',         # 1=Poorest to 5=Richest
    'v113': 'water_source',         # Drinking water source code
    'v116': 'sanitation_type',      # Toilet type code
    'v136': 'household_size',       # Number of household members
    'v025': 'urban_rural',          # 1=Urban, 2=Rural
    'v024': 'region',               # Region within country
}

COUNTRY_CODES = {
    'Nigeria':  1,
    'Rwanda':   2,
    'Ethiopia': 3,
}

# ── WATER SOURCE GROUPING ───────────────────────────────────────────────────
# DHS codes → 3 clean categories
def group_water(code):
    """
    Piped/protected = 0 (safe)
    Well/borehole   = 1 (moderate)
    Surface/other   = 2 (unsafe)
    """
    try:
        code = int(code)
    except:
        return np.nan
    if code in [10, 11, 12, 13, 14]:   # Piped water varieties
        return 0
    elif code in [20, 21, 30, 31, 40, 41, 51]:  # Well/borehole/spring
        return 1
    elif code in [32, 42, 43, 61, 62, 71, 96]:  # Surface/tanker/other
        return 2
    else:
        return np.nan

# ── SANITATION GROUPING ─────────────────────────────────────────────────────
def group_sanitation(code):
    """
    Flush toilet      = 0 (good)
    Pit latrine       = 1 (moderate)
    No facility/other = 2 (poor)
    """
    try:
        code = int(code)
    except:
        return np.nan
    if code in [10, 11, 12, 13, 14, 15]:   # Flush/pour flush
        return 0
    elif code in [20, 21, 22, 23, 41, 51]:  # Pit latrine varieties
        return 1
    elif code in [30, 31, 42, 43, 96]:      # No facility/open/other
        return 2
    else:
        return np.nan

# ── LOAD ONE COUNTRY ────────────────────────────────────────────────────────
def load_country(name, path):
    print(f"\n{'='*50}")
    print(f"Loading {name}...")

    if not os.path.exists(path):
        print(f"  ERROR: File not found at {path}")
        print(f"  Please check your folder structure.")
        return None

    # Load DTA file — convert categoricals to values
    df = pd.read_stata(path, convert_categoricals=False)
    print(f"  Raw shape: {df.shape[0]:,} rows × {df.shape[1]} columns")

    # Check target variable exists
    if TARGET not in df.columns:
        print(f"  ERROR: Target variable '{TARGET}' not found!")
        return None

    # Check which feature columns exist
    available = [col for col in FEATURES.keys() if col in df.columns]
    missing   = [col for col in FEATURES.keys() if col not in df.columns]

    if missing:
        print(f"  WARNING: Missing columns: {missing}")
        print(f"  Will fill with NaN and handle during cleaning.")

    # Extract target + available features
    cols_to_extract = [TARGET] + available
    df_clean = df[cols_to_extract].copy()

    # Add missing columns as NaN
    for col in missing:
        df_clean[col] = np.nan

    # Rename to readable names
    df_clean = df_clean.rename(columns=FEATURES)

    # ── CREATE TARGET VARIABLE ──
    # DHS stores Z-scores x100, so -200 means -2.0 SD (WHO stunting cutoff)
    df_clean['stunted'] = (df_clean[TARGET] < -200).astype(int)

    # Drop rows where target is missing/flagged (DHS uses 9999 for missing)
    df_clean = df_clean[df_clean[TARGET].notna()]
    df_clean = df_clean[df_clean[TARGET] < 9000]  # Remove flagged values
    df_clean = df_clean.drop(columns=[TARGET])

    # ── ADD COUNTRY COLUMN ──
    df_clean['country'] = COUNTRY_CODES[name]
    df_clean['country_name'] = name

    # ── CLEAN SPECIFIC VARIABLES ──

    # Mother BMI: stored as x100, convert to actual BMI
    if 'mother_bmi' in df_clean.columns:
        df_clean['mother_bmi'] = df_clean['mother_bmi'] / 100
        # Remove impossible BMI values
        df_clean.loc[df_clean['mother_bmi'] < 10, 'mother_bmi'] = np.nan
        df_clean.loc[df_clean['mother_bmi'] > 60, 'mother_bmi'] = np.nan

    # Birth weight: remove flagged/impossible values
    if 'birth_weight_grams' in df_clean.columns:
        df_clean.loc[df_clean['birth_weight_grams'] > 9000, 'birth_weight_grams'] = np.nan
        df_clean.loc[df_clean['birth_weight_grams'] < 500, 'birth_weight_grams'] = np.nan

    # Child age: keep only 0-59 months
    if 'child_age_months' in df_clean.columns:
        df_clean = df_clean[
            (df_clean['child_age_months'] >= 0) &
            (df_clean['child_age_months'] <= 59)
        ]

    # Group water source into 3 categories
    if 'water_source' in df_clean.columns:
        df_clean['water_source'] = df_clean['water_source'].apply(group_water)

    # Group sanitation into 3 categories
    if 'sanitation_type' in df_clean.columns:
        df_clean['sanitation_type'] = df_clean['sanitation_type'].apply(group_sanitation)

    # Remove DHS "missing" codes (usually 9, 99, 999 depending on variable)
    for col in ['child_sex', 'mother_education', 'wealth_index',
                'urban_rural', 'region']:
        if col in df_clean.columns:
            df_clean.loc[df_clean[col] >= 9, col] = np.nan

    # Report
    n_total   = len(df_clean)
    n_stunted = df_clean['stunted'].sum()
    pct       = (n_stunted / n_total * 100) if n_total > 0 else 0
    print(f"  Clean rows:    {n_total:,}")
    print(f"  Stunted:       {n_stunted:,} ({pct:.1f}%)")
    print(f"  Missing values per column:")
    for col in df_clean.columns:
        miss = df_clean[col].isna().sum()
        if miss > 0:
            print(f"    {col}: {miss:,} ({miss/n_total*100:.1f}%)")

    return df_clean


# ── MAIN PIPELINE ───────────────────────────────────────────────────────────
def run_pipeline():
    print("\n" + "="*50)
    print("  CHW STUNTING PREDICTION — DATA PIPELINE")
    print("="*50)

    # Create output directory
    os.makedirs('data', exist_ok=True)

    # Load all countries
    country_dfs = {}
    for name, path in DATA_PATHS.items():
        df = load_country(name, path)
        if df is not None:
            country_dfs[name] = df

    if len(country_dfs) == 0:
        print("\nERROR: No datasets loaded. Check your file paths.")
        return

    # ── COMBINE ──────────────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("Combining datasets...")
    combined = pd.concat(country_dfs.values(), ignore_index=True)
    print(f"  Combined shape: {combined.shape[0]:,} rows × {combined.shape[1]} columns")

    # ── HANDLE MISSING VALUES ─────────────────────────────────────────────────
    print("\nHandling missing values...")

    # Numerical columns: fill with median per country
    num_cols = ['birth_weight_grams', 'mother_bmi', 'household_size',
                'child_age_months', 'mother_age']
    for col in num_cols:
        if col in combined.columns:
            before = combined[col].isna().sum()
            combined[col] = combined.groupby('country')[col].transform(
                lambda x: x.fillna(x.median())
            )
            after = combined[col].isna().sum()
            print(f"  {col}: filled {before - after:,} missing values with country median")

    # Categorical columns: fill with mode per country
    cat_cols = ['child_sex', 'mother_education', 'wealth_index',
                'water_source', 'sanitation_type', 'urban_rural', 'region']
    for col in cat_cols:
        if col in combined.columns:
            before = combined[col].isna().sum()
            combined[col] = combined.groupby('country')[col].transform(
                lambda x: x.fillna(x.mode()[0] if len(x.mode()) > 0 else 0)
            )
            after = combined[col].isna().sum()
            print(f"  {col}: filled {before - after:,} missing values with country mode")

    # Drop any remaining rows with missing values
    before = len(combined)
    combined = combined.dropna()
    after = len(combined)
    print(f"\n  Dropped {before - after:,} rows with remaining missing values")

    # ── FINAL SUMMARY ─────────────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print("FINAL COMBINED DATASET SUMMARY")
    print(f"{'='*50}")
    print(f"Total rows:     {len(combined):,}")
    print(f"Total features: {len(combined.columns) - 2}")  # exclude country_name, stunted
    print(f"\nBy country:")
    for name, code in COUNTRY_CODES.items():
        subset = combined[combined['country'] == code]
        n = len(subset)
        s = subset['stunted'].sum()
        p = s/n*100 if n > 0 else 0
        print(f"  {name:12s}: {n:,} rows | {s:,} stunted ({p:.1f}%)")

    overall_pct = combined['stunted'].mean() * 100
    print(f"\n  Overall stunting prevalence: {overall_pct:.1f}%")

    # ── SAVE ──────────────────────────────────────────────────────────────────
    output_path = os.path.join('data', 'combined_data.csv')
    combined.to_csv(output_path, index=False)
    print(f"\nSaved to: {output_path}")

    # Save pipeline report
    report_path = os.path.join('data', 'pipeline_report.txt')
    with open(report_path, 'w') as f:
        f.write("CHW Stunting Prediction — Pipeline Report\n")
        f.write("="*50 + "\n\n")
        f.write(f"Total rows:     {len(combined):,}\n")
        f.write(f"Total features: {len(combined.columns) - 2}\n\n")
        f.write("Columns:\n")
        for col in combined.columns:
            f.write(f"  {col}\n")
        f.write("\nBy country:\n")
        for name, code in COUNTRY_CODES.items():
            subset = combined[combined['country'] == code]
            n = len(subset)
            s = subset['stunted'].sum()
            p = s/n*100 if n > 0 else 0
            f.write(f"  {name}: {n:,} rows | {s:,} stunted ({p:.1f}%)\n")

    print(f"Report saved to: {report_path}")
    print(f"\n✓ Pipeline complete! Run 2_model_training.py next.\n")

    return combined


if __name__ == '__main__':
    combined = run_pipeline()
